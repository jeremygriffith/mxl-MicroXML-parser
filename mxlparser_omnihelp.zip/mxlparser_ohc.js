var tocItems = [
[1,"mxl MicroXML Parser","mxl_parser.htm#Xxx1005"],
[2,"Table of Contents","mxl_parserTOC.htm#Xxx1021"],
[2,"MXL MicroXML Parser","ud_mxlparser.htm#Xxx1024"],
[3,"MXL Operation","ud_mxloperation.htm#Xxx1055"],
[3,"Data Model","ud_mxldata.htm#Xxx1063"],
[3,"SAX Callbacks","ud_mxlsax.htm#Xxx1074"],
[3,"Licensing","ud_mxllicense.htm#Xxx1089"]]
