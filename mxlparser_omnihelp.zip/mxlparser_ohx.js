// OmniHelp JS user-settable variables file, OHver 0.8

var mainName = ""

var newWindow = true
var closeWindow = false
var frameHigh = 350
var frameWide = 600
var frameOptions = ""
var frameBorder = false
var topFirst = true
var topHigh = 50
var leftWide = 220
var midHigh = 90

var showNavLeft = true
var topLeft = 'mxl MicroXML Parser <br />in OmniHelp'
var topButtons = true
var useStart = true
var usePrevNext = true
var useBackForward = true
var useHideShow = true
var validImg = 'ohvalidh.gif'
var validAlt = 'Valid HTML 4.01!'
var topRight = ''

var lowMem = false
var persistSettings = true
var ignoreCharsIX = "-[]()<>_"
var ignoreLeadCharsIX = ".$*"

var ctrlCssName = "ohctrl.css"
var mainCssName = "ohmain.css"
var IECtrlCssName = "ohctrl.css"
var N6CtrlCssName = "ohctrl.css"
var N4CtrlCssName = "ohctn4.css"
var IECssName = "ohmain.css"
var N6CssName = "ohmain.css"
var N4CssName = "ohmain.css"

var useNavToc = true
var useNavIdx = true
var useNavFts = true
var useNavRel = false

var tocGroupsOpen = false
var tocOpenLevel = 1
var tocIcoBase = "ohtc"
var tocExpand = true
var tocOpenCloseButtons = true

var idxGroupsOpen = false
var idxOpenLevel = 0
var idxIcoBase = "ohtc"
var idxExpand = true
var idxOpenCloseButtons = true
var idxSeeTerm = "See"
var idxSeeAlsoTerm = "See also"

var relShowSubjects = false

var listButton = true
var ftsHighlight  = true
var ftsHighlightStyle  = "background-color:yellow;"

var mergeProjects = [  ]
var mergeFirst = false

// end of mxlparser_ohx.js

